import Foundation

// Local classification only. A candidate is not an identity MATCH, a
// protected ownership proof, or a license to activate an external collector.
enum LocalScopeClassification: String, Sendable {
    case unknown = "UNKNOWN"
    case mismatch = "MISMATCH"
    case localCandidate = "LOCAL_SCOPE_CANDIDATE"
}

enum CodexLocalScope {
    private static func identifier(_ value: JSONValue?) -> String? {
        guard let s = value?.stringValue, !s.isEmpty, s.utf8.count <= 512,
              !s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        else { return nil }
        return s
    }
    private static func identity(_ result: JSONValue) -> (String, String)? {
        guard result["account"]?["type"]?.stringValue == "chatgpt",
              let user = identifier(result["userId"]),
              let workspace = identifier(result["workspaceRouting"]?["chatgptAccountId"])
        else { return nil }
        return (user, workspace)
    }
    static func evaluate(before: JSONValue, quota: JSONValue, after: JSONValue, clean: Bool) -> LocalScopeClassification {
        guard clean, let first = identity(before), let last = identity(after),
              let account = identifier(quota["accountId"])
        else { return .unknown }
        guard first.0 == last.0, first.1 == last.1, first.1 == account else { return .mismatch }
        guard quota["rateLimitsByLimitId"]?["codex"]?.objectValue != nil else { return .unknown }
        return .localCandidate
    }
}
