import Foundation

// Shared account and usage types for both native platform clients.

public struct AccountProfile: Codable, Identifiable, Equatable, Hashable, Sendable {
    public let id: UUID
    public var displayName: String
    public let email: String?
    public var accountID: String?
    public let createdAt: Date
    public var lastUsedAt: Date?

    public init(id: UUID, displayName: String, email: String?, accountID: String?, createdAt: Date, lastUsedAt: Date? = nil) {
        self.id = id; self.displayName = displayName; self.email = email
        self.accountID = accountID; self.createdAt = createdAt; self.lastUsedAt = lastUsedAt
    }

    public var initials: String {
        let parts = displayName
            .split(whereSeparator: { $0.isWhitespace })
            .prefix(2)
        let value = parts.compactMap(\.first).map(String.init).joined()
        return value.isEmpty ? "?" : value.uppercased()
    }
}

public struct AccountRegistry: Codable, Equatable, Sendable {
    public var activeAccountID: UUID?
    public var accounts: [AccountProfile]

    public init(activeAccountID: UUID?, accounts: [AccountProfile]) {
        self.activeAccountID = activeAccountID; self.accounts = accounts
    }

    public static let empty = AccountRegistry(activeAccountID: nil, accounts: [])
}

public enum AppLanguage: String, Codable, CaseIterable, Identifiable, Sendable {
    case system
    case english
    case simplifiedChinese

    public var id: String { rawValue }
}

public enum StatusBarUsageWindow: String, Codable, CaseIterable, Identifiable, Sendable {
    case fiveHour
    case weekly

    public var id: String { rawValue }
}

public struct AppSettings: Codable, Equatable, Sendable {
    public var language: AppLanguage
    public var showsMenuBarPercentage: Bool
    public var showsFiveHourUsage: Bool
    public var statusBarUsageWindow: StatusBarUsageWindow
    public var autoResetEnabled: Bool

    public static let `default` = AppSettings(
        language: .system,
        showsMenuBarPercentage: true,
        showsFiveHourUsage: false,
        statusBarUsageWindow: .fiveHour
    )

    public init(
        language: AppLanguage,
        showsMenuBarPercentage: Bool = true,
        showsFiveHourUsage: Bool = false,
        statusBarUsageWindow: StatusBarUsageWindow = .fiveHour,
        autoResetEnabled: Bool = false
    ) {
        self.language = language
        self.showsMenuBarPercentage = showsMenuBarPercentage
        self.showsFiveHourUsage = showsFiveHourUsage
        self.statusBarUsageWindow = statusBarUsageWindow
        self.autoResetEnabled = autoResetEnabled
    }

    public init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        language = try container.decodeIfPresent(AppLanguage.self, forKey: .language) ?? .system
        showsMenuBarPercentage = try container.decodeIfPresent(
            Bool.self,
            forKey: .showsMenuBarPercentage
        ) ?? true
        showsFiveHourUsage = try container.decodeIfPresent(
            Bool.self,
            forKey: .showsFiveHourUsage
        ) ?? false
        statusBarUsageWindow = try container.decodeIfPresent(
            StatusBarUsageWindow.self,
            forKey: .statusBarUsageWindow
        ) ?? .fiveHour
        autoResetEnabled = try container.decodeIfPresent(
            Bool.self, forKey: .autoResetEnabled
        ) ?? false
    }
}

public struct WeeklyUsage: Codable, Equatable, Sendable {
    public let remainingPercent: Int
    public let resetsAt: Date
    public let fiveHourRemainingPercent: Int?
    public let fiveHourResetsAt: Date?
    public let resetCreditsRemaining: Int?
    public let resetCredits: [BankedResetCredit]?
    /// Only reported values from the matching account/rateLimits/read response.
    public let planType: String?
    public let ordinaryUsageAllowed: Bool?

    public init(
        remainingPercent: Int,
        resetsAt: Date,
        fiveHourRemainingPercent: Int? = nil,
        fiveHourResetsAt: Date? = nil,
        resetCreditsRemaining: Int? = nil,
        resetCredits: [BankedResetCredit]? = nil,
        planType: String? = nil,
        ordinaryUsageAllowed: Bool? = nil
    ) {
        self.remainingPercent = remainingPercent
        self.resetsAt = resetsAt
        self.fiveHourRemainingPercent = fiveHourRemainingPercent
        self.fiveHourResetsAt = fiveHourResetsAt
        self.resetCreditsRemaining = resetCreditsRemaining
        self.resetCredits = resetCredits
        self.planType = planType
        self.ordinaryUsageAllowed = ordinaryUsageAllowed
    }
}

/// A real Codex quota with a nonstandard duration (such as Free 30D).
/// It must NEVER be mislabeled as a five-hour or seven-day window.
public struct NonWeeklyUsage: Codable, Equatable, Sendable {
    public let remainingPercent: Int
    public let windowDurationMins: Int
    public let resetsAt: Date
    public let resetCreditsRemaining: Int?
    /// Stable receipt time so re-rendering a cached snapshot cannot extend freshness.
    public let observedAt: Date

    public init(remainingPercent: Int, windowDurationMins: Int,
                resetsAt: Date, resetCreditsRemaining: Int? = nil,
                observedAt: Date = Date()) {
        self.remainingPercent = remainingPercent
        self.windowDurationMins = windowDurationMins
        self.resetsAt = resetsAt
        self.resetCreditsRemaining = resetCreditsRemaining
        self.observedAt = observedAt
    }

    public var windowLabel: String {
        if windowDurationMins % 1_440 == 0 { return "\(windowDurationMins / 1_440)D" }
        if windowDurationMins % 60 == 0 { return "\(windowDurationMins / 60)H" }
        return "\(windowDurationMins)m"
    }
}

public enum AccountUsageResult: Sendable {
    case weekly(WeeklyUsage)
    case nonWeekly(NonWeeklyUsage)
}

public struct UsageCacheEntry: Codable, Equatable, Sendable {
    public let profileID: UUID
    public let usage: WeeklyUsage
    public let fetchedAt: Date

    public init(profileID: UUID, usage: WeeklyUsage, fetchedAt: Date) {
        self.profileID = profileID; self.usage = usage; self.fetchedAt = fetchedAt
    }
}

public struct UsageCache: Codable, Equatable, Sendable {
    public var entries: [UsageCacheEntry]

    public init(entries: [UsageCacheEntry]) { self.entries = entries }

    public static let empty = UsageCache(entries: [])
}

public enum UsageViewState: Equatable, Sendable {
    case idle
    case loaded(WeeklyUsage)
    case stale(WeeklyUsage, String)
    case nonWeekly(NonWeeklyUsage)
    case staleNonWeekly(NonWeeklyUsage, String)
    case unavailable(String)

    public var displayedUsage: WeeklyUsage? {
        switch self {
        case let .loaded(usage), let .stale(usage, _):
            usage
        case .idle, .nonWeekly, .staleNonWeekly, .unavailable:
            nil
        }
    }

    public var nonWeeklyUsage: NonWeeklyUsage? {
        switch self {
        case let .nonWeekly(usage), let .staleNonWeekly(usage, _):
            usage
        default:
            nil
        }
    }

    public var refreshError: String? {
        switch self {
        case let .stale(_, message), let .staleNonWeekly(_, message): message
        default: nil
        }
    }
}

public struct AccountIdentity: Equatable, Sendable {
    public let accountID: String?
    public let email: String?

    public init(accountID: String?, email: String?) { self.accountID = accountID; self.email = email }

    public var suggestedDisplayName: String {
        guard let email, let localPart = email.split(separator: "@").first else {
            return "Codex Account"
        }
        return String(localPart)
    }

    public func matches(_ profile: AccountProfile) -> Bool {
        if let expected = profile.accountID, let actual = accountID {
            guard expected == actual else { return false }
            if let expectedEmail = profile.email, let actualEmail = email {
                return expectedEmail.caseInsensitiveCompare(actualEmail) == .orderedSame
            }
            return true
        }
        // Known workspace IDs must never merge with an email-only profile.
        guard profile.accountID == nil, accountID == nil else { return false }
        if let expected = profile.email, let actual = email {
            return expected.caseInsensitiveCompare(actual) == .orderedSame
        }
        return false
    }
}

public enum SwitchStage: String, CaseIterable, Sendable {
    case closeDesktop
    case saveCurrentCredential
    case activateTargetCredential
    case verifyTargetIdentity
    case commitActiveAccountID
    case reopenDesktop
}

public struct OperationError: LocalizedError, Equatable, Sendable {
    public let stage: SwitchStage?
    public let titleKey: String
    public let messageKey: String?
    public let message: String
    public let underlyingDescription: String?

    public init(stage: SwitchStage?, titleKey: String, messageKey: String?, message: String, underlyingDescription: String?) {
        self.stage = stage; self.titleKey = titleKey; self.messageKey = messageKey
        self.message = message; self.underlyingDescription = underlyingDescription
    }

    public var errorDescription: String? {
        let title = L10n.string(titleKey, language: .english)
        if let stage {
            return "\(title) (\(stage.rawValue)): \(message)"
        }
        return "\(title): \(message)"
    }

    public static func stage(_ stage: SwitchStage, _ error: any Error) -> OperationError {
        OperationError(
            stage: stage,
            titleKey: "switch_failed",
            messageKey: nil,
            message: error.localizedDescription,
            underlyingDescription: String(describing: error)
        )
    }
}

public enum AccountStoreError: LocalizedError, Equatable, Sendable {
    case profileNotFound
    case activeProfileMissing
    case activeCredentialMissing
    case activeCredentialMismatch
    case targetCredentialMissing
    case duplicateAccount
    case cannotRemoveActiveAccount

    public var errorDescription: String? {
        switch self {
        case .profileNotFound:
            "The account profile could not be found."
        case .activeProfileMissing:
            "No active account profile is configured."
        case .activeCredentialMissing:
            "The active Codex auth.json file is missing."
        case .activeCredentialMismatch:
            "Codex is signed in to a different account than Switcher expects. No saved credential was overwritten. Use Register Current Account to associate the current login before switching."
        case .targetCredentialMissing:
            "The selected account has no saved auth.json file."
        case .duplicateAccount:
            "This account is already saved. Select the existing account instead."
        case .cannotRemoveActiveAccount:
            "The active account cannot be removed."
        }
    }
}

public enum CodexClientError: LocalizedError, Equatable, Sendable {
    case executableNotFound
    case processLaunchFailed(String)
    case malformedResponse
    case remoteError(code: Int?, message: String)
    case connectionClosed
    case connectionClosedWithDetails(String)
    case timeout
    case identityUnavailable
    case weeklyUsageUnavailable
    case loginFailed(String)

    public var errorDescription: String? {
        switch self {
        case .executableNotFound:
            "The Codex executable could not be found."
        case let .processLaunchFailed(message):
            "Codex app-server failed to start: \(message)"
        case .malformedResponse:
            "Codex app-server returned malformed JSON."
        case let .remoteError(code, message):
            code.map { "Codex app-server error \($0): \(message)" } ?? "Codex app-server error: \(message)"
        case .connectionClosed:
            "Codex app-server closed the connection."
        case let .connectionClosedWithDetails(details):
            "Codex app-server closed the connection: \(details)"
        case .timeout:
            "Codex app-server did not respond before the timeout."
        case .identityUnavailable:
            "Codex did not return an account identity."
        case .weeklyUsageUnavailable:
            "No weekly Codex Usage window is available."
        case let .loginFailed(message):
            "Codex login failed: \(message)"
        }
    }
}
