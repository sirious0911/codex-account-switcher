import Foundation
#if os(Windows)
import SwitcherPlatform
#endif

/// Metadata-only preflight. A pinned image is not an owner lease, account
/// identity, scope match, permission to read usage, or activation grant.
public enum ScopeImageStatus: String, Sendable {
    case reviewed = "REVIEWED_IMAGE_ONLY"
    case mismatch = "IMAGE_NOT_REVIEWED"
    case unavailable = "IMAGE_UNAVAILABLE"
}
public enum ScopeImagePreflight {
    static let reviewedDesktopPin = "2a1ec3f1dd463fd30224be4c0c67d3fe83d3d863a3d7539ccad366952436d2aa"
    static func verify(path: String, pin: String) -> ScopeImageStatus {
        #if os(Windows)
        let r = path.withCString { p in pin.withCString { h in switcher_scope_image_pin(p, h) } }
        return r == 1 ? .reviewed : r == 0 ? .mismatch : .unavailable
        #else
        return .unavailable
        #endif
    }
    public static func inspect() -> ScopeImageStatus {
        #if os(Windows)
        guard let image = try? CodexExecutableLocator().locate() else { return .unavailable }
        return verify(path: image.path, pin: reviewedDesktopPin)
        #else
        return .unavailable
        #endif
    }
    public static var liveAllowed: Bool { false }
}
