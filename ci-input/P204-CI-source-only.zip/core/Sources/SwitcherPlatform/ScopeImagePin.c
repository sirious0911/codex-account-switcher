// Windows image metadata diagnostic only. Does not grant ownership or launch.
#include "SwitcherPlatform.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <stdlib.h>
#include <string.h>
static int nibble(char c) { return c >= '0' && c <= '9' ? c-'0' : c >= 'a' && c <= 'f' ? c-'a'+10 : -1; }
int32_t switcher_scope_image_pin(const char *path,const char *pin) {
    if(!path||!pin||strlen(pin)!=64)return -1;
    unsigned char expected[32],actual[32],buffer[65536];
    for(int i=0;i<32;i++){int a=nibble(pin[i*2]),b=nibble(pin[i*2+1]);if(a<0||b<0)return -1;expected[i]=(unsigned char)((a<<4)|b);}
    if(switcher_check_path(path)!=0)return -1;
    int chars=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,NULL,0);
    if(chars<=0||chars>32767)return -1;
    wchar_t *wide=calloc((size_t)chars,sizeof(wchar_t));if(!wide)return -1;
    if(!MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,wide,chars)){free(wide);return -1;}
    HANDLE h=CreateFileW(wide,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OPEN_REPARSE_POINT|FILE_FLAG_SEQUENTIAL_SCAN,NULL);
    free(wide);if(h==INVALID_HANDLE_VALUE)return -1;
    BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE hash=NULL;unsigned char *object=NULL;DWORD size=0,got=0;LARGE_INTEGER length;BY_HANDLE_FILE_INFORMATION info;int32_t result=-1;
    if(GetFileType(h)!=FILE_TYPE_DISK||!GetFileInformationByHandle(h,&info)||(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))||!GetFileSizeEx(h,&length)||length.QuadPart<=0||length.QuadPart>500000000)goto done;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0||BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,(PUCHAR)&size,sizeof(size),&got,0)<0||size==0||size>1048576)goto done;
    object=malloc(size);if(!object||BCryptCreateHash(alg,&hash,object,size,NULL,0,0)<0)goto done;
    LONGLONG total=0;
    for(;;){DWORD count=0;if(!ReadFile(h,buffer,sizeof(buffer),&count,NULL))goto done;if(!count)break;total+=count;if(total>length.QuadPart||BCryptHashData(hash,buffer,count,0)<0)goto done;}
    if(total!=length.QuadPart||BCryptFinishHash(hash,actual,sizeof(actual),0)<0||switcher_check_path(path)!=0)goto done;
    result=memcmp(expected,actual,32)==0?1:0;
done:
    if(hash)BCryptDestroyHash(hash);if(object)free(object);if(alg)BCryptCloseAlgorithmProvider(alg,0);CloseHandle(h);
    return result;
}
#else
int32_t switcher_scope_image_pin(const char *path,const char *pin){(void)path;(void)pin;return -1;}
#endif
