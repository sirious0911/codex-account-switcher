import Foundation
import Testing
@testable import SwitcherCore

struct CodexLocalScopeTests {
    private func identity(_ user: String = "fixture-user", _ workspace: String = "fixture-workspace") -> JSONValue {
        .object(["account": .object(["type": .string("chatgpt")]),
                 "userId": .string(user),
                 "workspaceRouting": .object(["chatgptAccountId": .string(workspace)])])
    }
    private func quota(_ account: String = "fixture-workspace") -> JSONValue {
        .object(["accountId": .string(account), "rateLimitsByLimitId": .object(["codex": .object([:])])])
    }
    @Test func exactLocalScope() {
        #expect(CodexLocalScope.evaluate(before: identity(), quota: quota(), after: identity(), clean: true) == .localCandidate)
    }
    @Test func changedUser() {
        #expect(CodexLocalScope.evaluate(before: identity(), quota: quota(), after: identity("other"), clean: true) == .mismatch)
    }
    @Test func changedWorkspace() {
        #expect(CodexLocalScope.evaluate(before: identity(), quota: quota(), after: identity("fixture-user", "other"), clean: true) == .mismatch)
    }
    @Test func wrongQuotaAccount() {
        #expect(CodexLocalScope.evaluate(before: identity(), quota: quota("other"), after: identity(), clean: true) == .mismatch)
    }
    @Test func missingIdentity() {
        #expect(CodexLocalScope.evaluate(before: .object([:]), quota: quota(), after: identity(), clean: true) == .unknown)
    }
    @Test func missingCodexBucket() {
        #expect(CodexLocalScope.evaluate(before: identity(), quota: .object(["accountId": .string("fixture-workspace")]), after: identity(), clean: true) == .unknown)
    }
    @Test func taintedSession() {
        #expect(CodexLocalScope.evaluate(before: identity(), quota: quota(), after: identity(), clean: false) == .unknown)
    }
    @Test func emptyIdentifier() {
        #expect(CodexLocalScope.evaluate(before: identity(" "), quota: quota(), after: identity(" "), clean: true) == .unknown)
    }
}
