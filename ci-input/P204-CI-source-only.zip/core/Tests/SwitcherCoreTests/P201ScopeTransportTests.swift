import Foundation
import Testing
@testable import SwitcherCore

private let scopeFixture = ProcessInfo.processInfo.environment["P201_SCOPE_RPC_EXE"]

@Suite(.enabled(if: scopeFixture != nil))
struct P201ScopeTransportTests {
    @Test(arguments: ["scope-valid","scope-mismatch","scope-changed","scope-notification","scope-missing"])
    func fixedScopeSequence(_ scenario: String) async throws {
        let home = FileManager.default.temporaryDirectory.appendingPathComponent("p201-rpc-fixture-\(UUID())")
        try FileManager.default.createDirectory(at: home, withIntermediateDirectories: false)
        defer { try? FileManager.default.removeItem(at: home) }
        try Data(scenario.utf8).write(to: home.appendingPathComponent("fixture-mode"))
        let client = CodexClient(locator: .init(explicitURL: URL(fileURLWithPath: try #require(scopeFixture))), requestTimeout: .seconds(5))
        let result = try await client.readUsageWithLocalScope(profileHome: home)
        let expected: LocalScopeClassification = scenario == "scope-valid" ? .localCandidate :
            (scenario == "scope-mismatch" || scenario == "scope-changed" ? .mismatch : .unknown)
        #expect(result == expected)
        #expect(try String(contentsOf: home.appendingPathComponent("fixture-complete"), encoding: .utf8) == "EXACT_SEQUENCE")
    }

    @Test func ordinaryQuotaPathDoesNotEnableExperimentalScope() async throws {
        let home = FileManager.default.temporaryDirectory.appendingPathComponent("p201-rpc-fixture-\(UUID())")
        try FileManager.default.createDirectory(at: home, withIntermediateDirectories: false)
        defer { try? FileManager.default.removeItem(at: home) }
        try Data("normal".utf8).write(to: home.appendingPathComponent("fixture-mode"))
        let client = CodexClient(locator: .init(explicitURL: URL(fileURLWithPath: try #require(scopeFixture))), requestTimeout: .seconds(5))
        let usage = try await client.readWeeklyUsage(profileHome: home)
        #expect(usage.remainingPercent == 42)
        #expect(usage.fiveHourRemainingPercent == 67)
        #expect(try String(contentsOf: home.appendingPathComponent("fixture-complete"), encoding: .utf8) == "EXACT_SEQUENCE")
    }
}
