import Foundation
import Testing
@testable import SwitcherCore

struct ScopeImagePreflightTests {
    @Test func noLivePermission() {
        #expect(!ScopeImagePreflight.liveAllowed)
    }
    #if os(Windows)
    @Test func exactFilePin() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("p204-image-fixture-\(UUID())")
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: false)
        defer { try? FileManager.default.removeItem(at: root) }
        let f = root.appendingPathComponent("fixture.exe")
        try Data("abc".utf8).write(to: f)
        let pin = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        #expect(ScopeImagePreflight.verify(path: f.path, pin: pin) == .reviewed)
        #expect(ScopeImagePreflight.verify(path: f.path, pin: String(repeating:"0", count:64)) == .mismatch)
        #expect(ScopeImagePreflight.verify(path: f.path, pin: "invalid") == .unavailable)
        #expect(ScopeImagePreflight.verify(path: root.path, pin: pin) == .unavailable)
        #expect(ScopeImagePreflight.verify(path: root.appendingPathComponent("absent.exe").path, pin: pin) == .unavailable)
    }
    #endif
}
