using System.Text.Json;
if(args.Length!=2||args[0]!="app-server"||args[1]!="--stdio")return 2;
var home=Environment.GetEnvironmentVariable("CODEX_HOME");
if(string.IsNullOrWhiteSpace(home)||!Path.GetFileName(home).StartsWith("p201-rpc-fixture-",StringComparison.Ordinal)||!Directory.Exists(home))return 3;
var mode=await File.ReadAllTextAsync(Path.Combine(home,"fixture-mode"));
if(mode is not ("scope-valid" or "scope-mismatch" or "scope-changed" or "scope-notification" or "scope-missing" or "normal"))return 4;
int step=0;
var sequence=mode=="normal"?new[]{"initialize","initialized","account/rateLimits/read"}:new[]{"initialize","initialized","account/read","account/rateLimits/read","account/read"};
while(await Console.In.ReadLineAsync() is {} line){
    if(line.Length>65536||step>=sequence.Length)return 5;
    using var d=JsonDocument.Parse(line);var x=d.RootElement;var method=x.GetProperty("method").GetString();
    if(method!=sequence[step])return 6;
    if(step==1){step++;continue;}
    var id=x.GetProperty("id").GetInt32();if(id!=(step==0?0:step-1))return 7;
    object result;
    if(step==0){
        bool experimental=x.GetProperty("params").TryGetProperty("capabilities",out var cap)&&cap.TryGetProperty("experimentalApi",out var e)&&e.GetBoolean();
        if(experimental!=(mode!="normal"))return 8;result=new{};
    }else if(method=="account/read"){
        if(x.GetProperty("params").GetProperty("refreshToken").GetBoolean())return 9;
        result=mode=="scope-missing"?new{account=new{type="chatgpt"}}:(object)new{account=new{type="chatgpt"},userId=mode=="scope-changed"&&step==4?"fixture-other":"fixture-user",workspaceRouting=new{chatgptAccountId="fixture-workspace"}};
        if(mode=="scope-notification"&&step==4)Console.WriteLine("""{"method":"account/updated","params":{}}""");
    }else{
        result=new{accountId=mode=="scope-mismatch"?"fixture-other":"fixture-workspace",rateLimitsByLimitId=new{codex=new{primary=new{usedPercent=33,windowDurationMins=300,resetsAt=2000000000},secondary=new{usedPercent=58,windowDurationMins=10080,resetsAt=2000000000}}}};
    }
    step++;
    // Record exact final request before sending its response.
    if(step==sequence.Length)File.WriteAllText(Path.Combine(home,"fixture-complete"),"EXACT_SEQUENCE");
    Console.WriteLine(JsonSerializer.Serialize(new{id,result}));Console.Out.Flush();
    if(step==sequence.Length)return 0;
}
return 10;
