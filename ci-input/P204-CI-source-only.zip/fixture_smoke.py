from pathlib import Path
import os, json, subprocess, tempfile
exe=Path.cwd()/"fixture/bin/Release/net10.0/P201RpcFixture.exe"
assert exe.is_file()
def run(mode,requests,expected_exit=0):
    with tempfile.TemporaryDirectory(prefix="p201-rpc-fixture-") as d:
        home=Path(d);(home/"fixture-mode").write_text(mode,encoding="utf-8")
        env={**os.environ,"CODEX_HOME":str(home)}
        r=subprocess.run([str(exe),"app-server","--stdio"],input="".join(json.dumps(x)+"\n" for x in requests),encoding="utf-8",capture_output=True,env=env,timeout=5)
        assert r.returncode==expected_exit,(mode,r.returncode)
        rows=[json.loads(x) for x in r.stdout.splitlines()]
        assert not r.stderr
        if expected_exit==0:assert (home/"fixture-complete").read_text()=="EXACT_SEQUENCE"
        else:assert not (home/"fixture-complete").exists()
        return rows
def requests(experimental):
    init={"method":"initialize","id":0,"params":{"clientInfo":{"name":"fixture"}}}
    if experimental:init["params"]["capabilities"]={"experimentalApi":True}
    rows=[init,{"method":"initialized","params":{}}]
    if experimental:rows+=[{"method":"account/read","id":1,"params":{"refreshToken":False}},{"method":"account/rateLimits/read","id":2,"params":{}},{"method":"account/read","id":3,"params":{"refreshToken":False}}]
    else:rows+=[{"method":"account/rateLimits/read","id":1,"params":{}}]
    return rows
for mode in ("scope-valid","scope-mismatch","scope-changed","scope-notification","scope-missing","normal"):
    rows=run(mode,requests(mode!="normal"))
    assert len(rows)==(2 if mode=="normal" else 5 if mode=="scope-notification" else 4)
    if mode=="scope-notification":assert rows[-2]["method"]=="account/updated"
    print("PASS fixture "+mode)
bad=requests(True);bad[2]["params"]["refreshToken"]=True
run("scope-valid",bad,9);print("PASS refreshToken rejected")
bad=requests(True);bad[2]["method"]="turn/start"
run("scope-valid",bad,6);print("PASS unexpected RPC rejected")
run("scope-valid",requests(False),8);print("PASS missing experimental capability rejected")
print("TOTAL 9/9 FIXTURE SELF-CHECK PASS")
