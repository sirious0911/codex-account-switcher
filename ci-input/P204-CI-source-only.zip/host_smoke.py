from pathlib import Path
import os, subprocess, tempfile, threading, queue, json, sys
host=Path(sys.argv[1]).resolve(); fixture=Path(os.environ["P201_SCOPE_RPC_EXE"]).resolve()
assert host.is_file() and fixture.is_file()
with tempfile.TemporaryDirectory(prefix="p204-host-empty-") as temp:
    root=Path(temp)
    env={**os.environ,"CODEX_CLI_PATH":str(fixture),"CODEX_HOME":str(root),"CODEX_SWITCHER_DATA_HOME":str(root/"switcher")}
    proc=subprocess.Popen([str(host)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding="utf-8",env=env,cwd=root)
    q=queue.Queue()
    def read():
        for line in proc.stdout:q.put(line)
    threading.Thread(target=read,daemon=True).start()
    try:
        proc.stdin.write(json.dumps({"id":1,"command":"scopePreflight"})+"\n");proc.stdin.flush()
        first=json.loads(q.get(timeout=10)); second=json.loads(q.get(timeout=10))
        assert first=={"kind":"scopePreflight","id":1,"imageStatus":"IMAGE_NOT_REVIEWED","ownerInitialized":False,"liveAllowed":False},first
        assert second=={"kind":"completed","id":1},second
        proc.stdin.write(json.dumps({"id":2,"command":"scopeEvidence"})+"\n");proc.stdin.flush()
        denied=json.loads(q.get(timeout=10));assert denied=={"kind":"completed","id":2,"error":"SCOPE_LIVE_ADMISSION_HOLD"},denied
        assert not (root/"auth.json").exists() and not (root/"fixture-complete").exists() and not (root/"switcher").exists()
        proc.stdin.close();assert proc.wait(timeout=10)==0
        print("P204_HOST_PREFLIGHT_AND_LIVE_DENIAL_PASS")
    finally:
        if proc.poll() is None:proc.kill();proc.wait(timeout=5)
