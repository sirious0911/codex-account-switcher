$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Set-Location -LiteralPath $PSScriptRoot
$manifest = Get-Content -LiteralPath 'manifest.json' -Raw | ConvertFrom-Json
foreach ($item in $manifest) {
    if ($item.path -notmatch '^(core/(Sources|Tests)/[^:]+|core/Package\.swift|fixture/(Program\.cs|P201RpcFixture\.csproj)|fixture_smoke\.py|host_smoke\.py|run-build\.ps1)$' -or $item.path -match '(\.\.|\\)') { throw 'Unexpected manifest path' }
    $actual = (Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $item.sha256) { throw 'Source manifest mismatch' }
}
if ($manifest.Count -ne 44) { throw 'Unexpected manifest count' }
if (-not (Get-Command swift -ErrorAction SilentlyContinue)) { throw 'Swift toolchain missing' }
swift --version
if ($LASTEXITCODE -ne 0) { throw 'Swift version failed' }
dotnet build fixture/P201RpcFixture.csproj -c Release --nologo
if ($LASTEXITCODE -ne 0) { throw 'Fixture build failed' }
python fixture_smoke.py
if ($LASTEXITCODE -ne 0) { throw 'Fixture self-check failed' }
$env:P201_SCOPE_RPC_EXE = (Resolve-Path -LiteralPath 'fixture/bin/Release/net10.0/P201RpcFixture.exe').Path
# Existing transport suite uses a separate fixture; do not point it at P201.
# Optional prior fixture only if independently supplied by reviewed CI.
Remove-Item Env:SWITCHER_TEST_INSTALLED_CLI -ErrorAction SilentlyContinue
Push-Location core
try {
    swift test --filter P201ScopeTransportTests
    if ($LASTEXITCODE -ne 0) { throw 'Scope transport tests failed' }
    swift test
    if ($LASTEXITCODE -ne 0) { throw 'Shared core regression failed' }
    swift build -c release --product SwitcherHost
    if ($LASTEXITCODE -ne 0) { throw 'Windows SwiftHost build failed' }
    $bin = swift build -c release --show-bin-path
    if ($LASTEXITCODE -ne 0) { throw 'Host lookup failed' }
    Get-FileHash -LiteralPath (Join-Path $bin 'SwitcherHost.exe') -Algorithm SHA256
    python ../host_smoke.py (Join-Path $bin 'SwitcherHost.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Host preflight smoke failed' }
} finally { Pop-Location }
